package com.muvitte.hohoton_rules_droid_team;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.muvitte.hohoton_rules_droid_team.databinding.ActivityMainBinding;

public class MainActivity extends Activity {

    private TextView mTextView;
    private ActivityMainBinding binding;

    com.google.android.gms.maps.MapFragment googleMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        createMapView();
        //addMarker();
    }

    //private void addMarker() {

        //if (null != googleMap){

            //googleMap.addMarker(new MarkerOptions()
                    //.position(new LatLng(0,0))
                    //.title("Marker")
                    //.draggable(true)

            //);

        //}

    //}

    private void createMapView() {

        try {

            if (null == googleMap){

                googleMap = ((MapFragment) getFragmentManager().findFragmentById(R.id.mapView));

                if (null == googleMap) {

                    Toast.makeText(getApplicationContext(), "Error creating map", Toast.LENGTH_SHORT).show();

                }

            }

        } catch (NullPointerException exception) {

            Log.i("mapApp", exception.toString());

        }

    }
}